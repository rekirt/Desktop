#!/bin/bash
#display user information from the system
echo "User info for userid:$USER"
echo UID:$UID
echo HOME:$HOME


