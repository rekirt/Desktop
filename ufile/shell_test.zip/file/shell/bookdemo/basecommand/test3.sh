#!/bin/bash
days=10
guest="kitty"
echo "$guest checked in $days ago"
days=5
guest=maggie
echo "$guest checked in $days ago"

