#!/bin/bash
# this script display the date and who's logged on 
echo -n "The time and date are :"
date
echo "Let's see who's logged the system: "
who


