// Copyright (c) 2014 Intel Corporation. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "xwalk/experimental/native_file_system/virtual_root_provider.h"

#include "base/logging.h"

VirtualRootProvider::VirtualRootProvider() {
  // TODO(darktears): Mac support to be added.
  NOTIMPLEMENTED();
}
