// Copyright (c) 2013 Intel Corporation. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "xwalk/runtime/common/android/xwalk_globals_android.h"

// The pak name should be the same as defined in xwalk.gyp
const char kXWalkPakFilePath[] = "xwalk.pak";
